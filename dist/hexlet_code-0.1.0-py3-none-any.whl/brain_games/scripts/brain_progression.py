#!/ur/bin/env python3


from brain_games.logic1 import structure
from brain_games.games import logic_progression

def main():
    structure(logic_progression)


if __name__ == '__main__':
    main()
