#!/ur/bin/env python3


from brain_games.logic1 import structure
from brain_games.games import logic_prime

def main():
    structure(logic_prime)


if __name__ == '__main__':
    main()
