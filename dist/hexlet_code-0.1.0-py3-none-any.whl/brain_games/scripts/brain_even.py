#!/ur/bin/env python3


from brain_games.logic1 import even


def main():
    print('Welcome to the Brain Games!')
    even()


if __name__ == '__main__':
    main()
