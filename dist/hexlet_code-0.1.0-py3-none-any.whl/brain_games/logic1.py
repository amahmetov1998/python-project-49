import prompt
from random import randint


def even():
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}!')
    print('Answer "yes" if the number is even, otherwise answer "no".')
    i = 0
    c = 3

    while i < c:
        random_number = randint(1, 100)
        answer = prompt.string(f'Question: {random_number}\nYour Answer: ')
        if (random_number % 2 == 0 and answer == 'yes') or (random_number % 2 != 0 and answer == 'no'):
            print('Correct!')
            i = i + 1
        elif (random_number % 2 == 0 and answer == 'no') or (random_number % 2 != 0 and answer == 'yes'):
            return print('\'no\' is wrong answer ;(. Correct answer was \'yes\'.')
        else:
            return print(f'{answer} is wrong answer ;(.')
    print(f'Congratulations, {name}!')
