### Hexlet tests and linter status:
[![Actions Status](https://github.com/amahmetov1998/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/amahmetov1998/python-project-49/actions)
<a href="https://codeclimate.com/github/amahmetov1998/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/dcc1a26a056d716f76e1/maintainability" /></a>
