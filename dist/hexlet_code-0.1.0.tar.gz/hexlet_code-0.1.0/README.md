### Hexlet tests and linter status:
[![Actions Status](https://github.com/amahmetov1998/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/amahmetov1998/python-project-49/actions)
<a href="https://codeclimate.com/github/amahmetov1998/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/dcc1a26a056d716f76e1/maintainability" /></a>
https://asciinema.org/a/8lBjcA7LzXnMcflaevINSfTej (even)
https://asciinema.org/connect/530bce02-c8be-4f39-a9eb-0ec48d18c303 (calc)
https://asciinema.org/a/LN3fGxIGtf9SEVfQGffluySYQ (gcd)
https://asciinema.org/a/qZmbNgpoFovXXl7sxPzugOMiu (progression)
